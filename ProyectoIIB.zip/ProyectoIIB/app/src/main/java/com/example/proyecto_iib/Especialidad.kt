package com.example.proyecto_iib

class Especialidad (
        var cod_especialidad: Int,
        var nombre_especialidad: String?
        )