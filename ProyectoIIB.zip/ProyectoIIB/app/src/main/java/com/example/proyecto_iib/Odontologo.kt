package com.example.proyecto_iib

class Odontologo (
    var cod_odontologo: String,
    var nombre_odontologo: String?,
    var apellido_odontologo: String?,
    var telefono_odontologo: Int?,
    var correo_odontologo: String?,
    var contraseña_odontologo: String?,
    var especialidad: String?,
    var dias_habiles: MutableList<String>,
    var hora_atencion_inicio: String,
    var hora_atencion_final: String

)



