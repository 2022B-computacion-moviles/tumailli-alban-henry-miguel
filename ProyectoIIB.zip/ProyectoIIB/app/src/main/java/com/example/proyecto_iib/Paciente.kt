package com.example.proyecto_iib


class Paciente(
    var nombre:String,
    var fechaUltimaCita:String
) {
}

